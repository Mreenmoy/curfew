<?php
session_start();
//error_reporting(0);
include('includes/dbconnection.php');

  ?>
  <!doctype html>
<html lang="en" class="no-js">
<head>
	<meta charset="UTF-8">
	<meta name="viewport" content="width=device-width, initial-scale=1">

	<link href='http://fonts.googleapis.com/css?family=Ubuntu:400,700' rel='stylesheet' type='text/css'>

	<link rel="stylesheet" href="css/reset.css"> <!-- CSS reset -->
	<link rel="stylesheet" href="css/style.css"> <!-- Resource style -->
	<script src="js/modernizr.js"></script> <!-- Modernizr -->
  	
	<title>COVID-19</title>
</head>
<body>

		

		

<main id="cd-main-content">
	<section id="cd-intro">
		<b><h1>COVID - 19</h1></b>

		<header class="cd-header">
			<div id="cd-logo"><a href="#0"><img src="img/co1" alt="Logo"></a></div>
			<a class="cd-menu-trigger" href="#main-nav">Menu<span></span></a>
		</header>
		<div class="cd-blurred-bg"></div>
	</section> <!-- cd-intro -->
</main>








</main>

<div class="cd-shadow-layer"></div>

<nav id="main-nav">
	<ul>
		<li><a href="create-pass.php"><span>create pass</span></a></li>
		<li><a href="search-pass.php"><span>search pass</span></a></li>
		<li><a href="admin/index.php"><span>Admin</span></a></li>
		<li><a href="#0"><span>About</span></a></li>
		<li><a href="#0"><span>Contact us</span></a></li>
	</ul>
	<a href="#0" class="cd-close-menu">Close<span></span></a>
</nav>

<script src="http://ajax.googleapis.com/ajax/libs/jquery/1.11.0/jquery.min.js"></script>
<script src="js/main.js"></script> <!-- Resource jQuery -->
</body>
</html>