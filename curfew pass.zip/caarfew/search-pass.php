<?php
session_start();
//error_reporting(0);
include('includes/dbconnection.php');

  ?>
  <!DOCTYPE html>
  <html>
  <head>
  	<title>COVID-19</title>
 
<meta name="keywords" content="Resort Inn Responsive , Smartphone Compatible web template , Samsung, LG, Sony Ericsson, Motorola web design" />

<link rel="stylesheet" href="search pass/vendors/bootstrap/bootstrap.min.css">
  <link rel="stylesheet" href="search pass/vendors/themify-icons/themify-icons.css">
  <link rel="stylesheet" href="search pass/vendors/owl-carousel/owl.theme.default.min.css">
  <link rel="stylesheet" href="search pass/vendors/owl-carousel/owl.carousel.min.css">
 <link rel="stylesheet" href="style.css">




  	<link rel="stylesheet" type="text/css" href="search pass/create.css">
  	  </head>
  <body>
   <div>
    <h1><a href="index.php">home</a> </h1>
</div>
	<body style="background-color: black;">
<!-- partial:index.partial.html -->


<div class="container demo">
   <div class="content">
      <div id="large-header" class="large-header">
         <canvas id="demo-canvas"></canvas>
         <font color="green"<h1 class="main-title"><span class="thin">Search your pass here</span> </h1></font>
         	  
   </div>
</div>

  <!--================ Header Menu Area start =================-->
 <?php include_once('search pass/header.php');?>
  <!--================Header Menu Area =================-->

  <!--================ Domain Search section start =================-->
 
    <div class="container">
      <div class="row no-gutters">
      
        	
        </div>
        
          <form class="form-inline flex-nowrap form-domainSearch" method="post">
            <div class="form-group">
            <div class="search box">
              <label for="staticDomainSearch" class="sr-only">Search</label>
              <input id="searchdata" type="text" name="searchdata" required="true" class="form-control" placeholder="Enter Your Pass ID"> 
            </div>
            <div>
            <button type="submit" class="button rounded-0" name="search" id="submit">Search</button></div></div></div>
          </form>
           <?php
if(isset($_POST['search']))
{ 
$sdata=$_POST['searchdata'];
  ?>
  <font color="brown"><h4  align="center">Result against "<?php echo $sdata;?>" E-pass </h4></font>

     <table class="table table-striped table-bordered table-hover" id="dataTables-example">
 <?php
$sql="SELECT * from tblpass where PassNumber like '%$sdata%'";
$query = $dbh -> prepare($sql);
$query->execute();
$results=$query->fetchAll(PDO::FETCH_OBJ);

$cnt=1;
if($query->rowCount() > 0)
{
foreach($results as $row)
{               ?>
      
    <tr align="center">
<td colspan="6" style="font-size:20px;color:orange">
 Pass ID: <?php  echo ($row->PassNumber);?></td></tr>




  <tr>
    <th scope>Full Name</th>
    <td><?php  echo ($row->FullName);?></td>
    <th scope>Mobile Number</th>
    <td><?php  echo ($row->ContactNumber);?></td>
    <th scope>Email</th>
    <td><?php  echo ($row->Email);?></td>
  </tr></tr>

<tr>
    <th scope>Identity Type</th>
    <td><?php  echo ($row->IdentityType);?></td>
    <th scope>Identity Card Number</th>
    <td><?php  echo ($row->IdentityCardno);?></td>
    <th scope>Category</th>
    <td><?php  echo ($row->Category);?></td>
  </tr>
<tr>
    <th scope>From Date</th>
    <td><?php  echo ($row->FromDate);?></td>
    <th scope>To Date</th>
    <td><?php  echo ($row->ToDate);?></td>
    <th scope>Pass Creation Date</th>
    <td><?php  echo ($row->PasscreationDate);?></td>
  </tr>
                                   
    <?php 
$cnt=$cnt+1;
} } else { ?>
  <tr>
    <td colspan="8"> No record found against this search</td>

  </tr>
   
<?php } }?> 
     </table>

        </div>
      </div>
    </div>
  </section>
  <!--================ Domain Search section end =================-->


  <!-- ================ start footer Area ================= -->
   <?php include_once('search pass/footer.php');?>
  <!-- ================ End footer Area ================= -->






<!-- animation partial -->
  <script src='https://s3-us-west-2.amazonaws.com/s.cdpn.io/499416/TweenLite.min.js'></script>
<script src='https://s3-us-west-2.amazonaws.com/s.cdpn.io/499416/EasePack.min.js'></script>
<script src='https://s3-us-west-2.amazonaws.com/s.cdpn.io/499416/demo.js'></script><script  src="search pass/script.js"></script>










</body>
</html>
