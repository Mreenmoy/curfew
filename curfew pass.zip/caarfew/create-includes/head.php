<nav class="navbar navbar-default navbar-fixed-top" role="navigation" id="navbar">
            <!-- navbar-header -->
            <div class="navbar-header">
                <button type="button" class="navbar-toggle" data-toggle="collapse" data-target=".sidebar-collapse">
                    <span class="sr-only">Toggle navigation</span>
                    <span class="icon-bar"></span>
                    <span class="icon-bar"></span>
                    <span class="icon-bar"></span>
                </button>
                <a class="navbar-brand" href="index.php">
                    <strong style="color: purple;font-size: 30px">COVID-19</strong>
                </a>
            </div>
            <!-- end navbar-header -->
            <!-- navbar-top-links -->
            <ul class="nav navbar-top-links navbar-right">
                <!-- main dropdown -->
                 
   
                <div>
                <li class="dropdown">
                   
                      <a class="dropdown-toggle" data-toggle="dropdown" href="index.php">
                        <a i class="fa fa-home fa-3x"href="index.php"></i>
                    </a>

                    <!-- dropdown user-->
                  </li></div>
                        <li>
                        <li>
                    </li>
                        <li class="divider"></li>
                        
                        
                    </ul>
                    <!-- end dropdown-user -->
                </li>
                <!-- end main dropdown -->
            </ul>
            <!-- end navbar-top-links -->

        </nav>